# Aprenem en moviment

Web inicial del projecte grupal de l'assignatura *Pedagogia i Principis Didàctics de l'AFE*.

## Publicar amb GitHub Pages
1. Creeu un repositori a GitHub, per exemple `aprenem-en-moviment`.
2. Pugeu-hi `index.html` a l'arrel del repositori.
3. Obriu **Settings → Pages**.
4. A **Build and deployment**, seleccioneu **Deploy from a branch**.
5. Seleccioneu la branca `main` i la carpeta `/ (root)`, i deseu.
6. Quan acabi el desplegament, GitHub Pages mostrarà la URL pública del lloc.

## Actualitzar la web
Podeu editar `index.html` directament a GitHub (icona del llapis) o treballar amb una còpia local i pujar els canvis. Cada commit a la branca publicada tornarà a desplegar la pàgina.

## Notes
- HTML, CSS i JavaScript en un únic fitxer, sense dependències externes.
- Els continguts acadèmics concrets s'incorporaran a partir dels materials reals de l'assignatura.
- Substituïu els quatre noms provisionals quan decidiu què mostrar a la secció de l'equip.
